// javascript
	function validateForm() {
				var name = document.forms["msgForm"]["name"].value;
				var email = document.forms["msgForm"]["email"].value;
				var phone = document.forms["msgForm"]["phone"].value;
				var message = document.forms["msgForm"]["message"].value;

				if (name == "" || email == "" || phone == "" || message == ""){
					alert("Please fill all the field.");
				}
				else {
					alert("Thank you for the feedback.");
				}
			}
			
		