from read import *
import datetime                          # importing date and file.
def Book_Return():
    dic = read()
    Buy_Again=True
    Name_Of_User=input("Enter the name of user: ")
    Total_Price=0.0
    while Buy_Again==True:
        while True:
          try:
           Number_For_Book=int(input("Enter the number assign to the book you want to return: "))
           break
          except:
            print("book number doesnt match")
        else:
          False
        file=open(Name_Of_User+"Return.txt","a")
        Quantity_input=int(input("Enter the quantity of books you want to return: " ))
        Total_Price+=float(dic[str(Number_For_Book)]["Price"])*Quantity_input
        file.write(dic[str(Number_For_Book)]["Name"]+" is the book number you want to return")
        file.write("\n")
        file.write(str(Quantity_input)+" is the quantity of the book you want return")
        file.write('\n')
        file.write(str(Total_Price)+" is the amount you have paid for books")
        file.write("\n")
        return_time=str(datetime.datetime.now())        #prints date and time 
        file.write("the time you return the book is : "+return_time)
        file.write("\n")
        file.write("\n")
        returns_now=input("If you want to return more books, press y=yes, other-key=No: ")
        if returns_now=="y":
            Buy_Again=True
        else:
            Buy_Again=False
    fine_input= input("Enter the number of days you kept the book with you: ")
    days = int(fine_input)

    if days<10:
        print("no fine is applied")
        s=0
        dayfine=0
        days=0
        totalfine = int((days - 10) * dayfine * s)   # calculation of fine if  return before 10 days.
        file.write(str(totalfine) + "is the fine you should pay")
    elif days >= 10:
        print( "fine is applied")
        dayfine=input("please enter Fine amount per day") #fine rate is given by programe user.
        dayfine=int(dayfine)
        numberofbook=input("please enter the no. of book you have burrowed: ")
        s=int(numberofbook)
        totalfine=int((days-10)*dayfine*s)                 #calculation of fine if return after 10 days.
        print(totalfine)
    file.write(str(totalfine)+"is the amount you should pay as fine")
    file.write("\n")
    file.write(str(Total_Price)+" is the total payable amount for books")
    file.close()
