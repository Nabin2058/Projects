def read():                      #function has been defined

    dic = {}                         #dictionary has been assign.
    file = open("list_Of_Book.txt",'r')         #Reading the file
    to = 1                            #intializing counter variable from 1.
    for line in file:                 #for loop to search 'comma' to split lines. it stops when it doesnt find comma.
        a = line.split(",")          #split the text with the help of comma.
        name = a[0]              ##Assinging the key value
        author = a[1]                              # number to the dictionary
        quantity = a[2]
        price = a[3]                                                  ##
        dic[str(to)]={'Name':name, 'Author': author,'Quantity':quantity,'Price':price}
        to = to + 1                     #counter variable increase with 1 .
    return(dic)

