from read import *
from Buy_Write import *
from DisplayInfo import *
from Update_Books import *
from Book_Return import *
from UpdateReturn import *
print("""

what application perforn these task
1 = display the book which are available in Library
2 = select books and bills
3 = return book
4 = update book quantity after a user burrow the book
5 = update book quantity afte a user return the book
""")

while True:
     Enter = input("choose the number for above service: ")
     while True:
          if Enter== "1":
               DisplayInfo()
               break
          elif Enter== "2":
               write()
               break
          elif Enter== "3":
               Book_Return()
               break
          elif Enter== "4":
               Update_Books()
               break
          elif Enter== "5":
               UpdateReturn()
               break
          else:
              print("Please, Enter valid number")
              break
