from read import*
def Update_Books():
    dic=read()
    print(dic)
    Update_Again=True
    while Update_Again==True:
      Book_Number=(input('Which book number is to be updated: '))
      numUpdate = (input('Type the number of books to update: '))
      books = dic[Book_Number]['Quantity']
      update = int(books) - int(numUpdate)   #subtract the nu ber of book to update the book number in the library.
      fun = open("List_Of_Book.txt", "w")               
      for i in range(1, 11):
          i = str(i)
          if Book_Number == i:
              dic[i]["Quantity"] = str(update)
          first = dic[i]["Name"] + "," + dic[i]["Author"] + "," + str(dic[i]["Quantity"]) + "," + str(dic[i]["Price"]) + ",\n"
          fun.write(first)
      print(update)
      print(dic)
      More_Update = input("Do you want to update again y/n")
      if More_Update== "y":
          Update_Again:True

      else:
          Update_Again = False

    print(update)
    print(dic)
