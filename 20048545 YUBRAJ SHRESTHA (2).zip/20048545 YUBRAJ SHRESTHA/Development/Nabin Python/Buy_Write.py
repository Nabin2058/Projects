from read import *                  #importing the file
import datetime                       #importing date and time
def write():

    dic = read()
    print(dic ,"are the books in the library")  #printing dictionary that contains the list of books
    Buy_Again=True
    Name_Of_User = str(input("Enter Name of user: "))        #user input for user name
    file = open(Name_Of_User+".txt","a")                #file saved as text file(.txt) and file name wiil be user name.
    file.write('|||Letang Library Management System|||')     #writing text
    file.write("\n")                                  #this will help to write file in another line.
    file.write('Bring all bills when you return the book')
    file.write("\n")
    file.write("Fine is added after 10 days")
    file.write("\n")
    file.write(Name_Of_User+" borrows the books")
    file.write("\n")
    Total_Price=0.0                               #total amount has been defined
    while Buy_Again == True:
        while True:         
         try:
          Number_For_Book=int(input("Enter the number assign to book you want to borrow: "))
          break
         except Exception as e:
           print("please enter valid number")
         else:
             False


        while True:
           try:
             Quantity_input=int(input("Enter the quantity of the book you want: "))
             break
           except Exception as e:
                print("please enter the valid number")
           else:
               False

        file=open(Name_Of_User+".txt","a")      #creats a new text file and file name will be the name of user
        Total_Price+=float(dic[str(Number_For_Book)]["Price"])*Quantity_input    #calculating the total Price
        file.write(dic[str(Number_For_Book)]["Name"]+" is the book you want") #writing in the text file.
        file.write("\n")
        file.write(str(Quantity_input)+" is the quantity of the book you want")
        file.write('\n')
        file.write(str(Total_Price)+" is the amount you have to pay")
        file.write("\n")
        buy_time=str(datetime.datetime.now())
        file.write("The time you bought the book "+buy_time)
        file.write("\n")
        file.write("\n")
        buy = input("Do you want to buy again yes/no? press y for yes and any other key for No: ")
        if buy == "y":                                    #if yes than the value of buy_gain will be true.
            Buy_Again=True
        else:
            Buy_Again=False          #if pressed other value of Buy_Again will be false and the loop ends

    file.write(str(Total_Price)+" is the total amount you have to pay")
    print(Total_Price)             #total amount of book is printed
    file.write("\n")
    file.close()
