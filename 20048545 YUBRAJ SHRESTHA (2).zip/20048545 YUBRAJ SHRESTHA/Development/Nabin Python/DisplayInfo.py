def DisplayInfo():
    print('______________________________________________________')
    
    print('BOOK NAME   , AUTHOR    , QUANTITY,  PRICE')
    
    print('......................................................')
    file = open("List_Of_Book.txt","r").readlines()
    for i in range(len(file)):
        print(i)
        print(file[i])
    print('_____________________________________________________ ')
DisplayInfo()
