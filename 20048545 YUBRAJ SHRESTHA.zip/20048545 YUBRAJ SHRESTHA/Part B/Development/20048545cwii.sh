#!/bin/bash


promptUser() { # Prompts the user
    echo "Your name is $1 and your ID number is $2"
    echo "Time: $(date)"
    echo "-------------Welcome-------------"
    echo "----------To My Program----------"
    listOfBand
}

listOfBand(){ # Lists of the bands
    echo "The lists of the bands are as follow ::"
    echo "1. Beatles => BEATLES"
    echo "2. ACDC => ACDC"
    echo "3. Queen => QUEEN"
    echo "4. Blondie => BLONDIE"
    echo "5. Nirvana => NIRVANA"
    chooseBand
}

chooseBand(){ # The function that allow to choose the band
    favBand='NIRVANA'
    echo "Choose your favorite band"
    read -p "Enter the code of your favorite band: " bandCode
    while [[ $bandCode != $favBand ]]; do
        echo "You have entered the $bandCode"
        echo "Please try to choose again"
        read -p "Enter the code of your favorite band: " bandCode
    done
    echo "You have entered the $bandCode"
    echo "You have chosen the band Nirvana"
    showBandMembers
}

showBandMembers(){ # function that shows the band members
    echo "Member of the band."
    echo "John Lennon => JL"
    echo "Angus Young => AY"
    echo "Freddie Mercury => FM"
    echo "Debbie Harry => DH"
    echo "Kurt Cobain => KC"
    chooseBandMember
}

chooseBandMember(){ # function that allow you to choose the band member
    echo "Please select the three member!"
    echo "Please! select the member and use their respective member code to select. : "
    read members
    firstWord=""
    secondWord=""
    thirdWord=""
    while [[ $firstWord == "" ]]
    do
        for member in $members
        do
            if [[ $member == "JL" || $member == "AY" || $member == "FM" || $member == "DH"
            || $member == "KC" ]]
            then
                if [[ $firstWord == "" ]]
                then
                    firstWord=$member
                elif [[ $secondWord == "" ]]
                then
                    if [[ $firstWord == $member ]]
                    then
                        echo "The member code of, $member is repeated!. Enter
                        the code of 3 different member code!!!"
                        echo ""
                        showBandMembers
                    else
                        secondWord=$member
                    fi
                elif [[ $firstWord == $member || $secondWord == $member ]]
                then
                    echo "The member code of, $member is repeated!. Enter
                        the code of 3 different member code!!!"
                    echo ""
                    showBandMembers
                else
                    choosedMember $members
                fi
            else
                echo "ERROR!!!, Please use respective member code which are listed below."
                showBandMembers
            fi
        done
    done
    
}

choosedMember(){ # The function to display the choosed member
    if [[ $# == 3 ]]; then
        echo "The member of band that you have selected are as follow :"
        PS3="Choose a member of the Band: "
        select selectedmembers in $members
        do
            case $selectedmembers in
                JL)
                    displayFile "jl.txt"
                break;;
                AY)
                    displayFile "ay.txt"
                break;;
                FM)
                    displayFile "fm.txt"
                break;;
                DH)
                    displayFile "dh.txt"
                break;;
                KC)
                    displayFile "kc.txt"
                break;;
                *)
                    echo "You chose a wrong number"
                    showBandMembers
            esac
        done
        userinput
    else
        echo "You have to choose 3 members"
        showBandMembers
    fi
    
    
}

displayFile(){ # The functions to display the file of the member that you have choosed.
    if [ -f $1 ]
    then
        echo "The biography of band member is as follows:"
        cat $1
    else
        echo "Sorry, the file does't exist."
        listOfBand
    fi
}

userinput(){ # function to ask user to choose again or exit
    echo -e "\n Do you want to continue? (yes/no)"
    read input
    if [[ $input == "y" || $input == "Y" || $input == "yes" || $input == "Yes" ]]; then
        listOfBand
    elif [[ $input == "n" || $input == "N" || $input == "no" || $input == "No" ]]; then
        echo "Have a good luck."
        exit
    else
        echo "You have to choose: y or n"
        userinput
    fi
}
start(){ # the function to start the program
    secretkey=555
    count=3
    until [ $count -eq 0 ]
    do
        read -s -p "Enter the password: " key
        if [ $key -eq $secretkey ]; then
            echo -e "\nThe key you have entered is correct."
            promptUser $1 $2
            break
        else
            echo "You have $(($count-1)) tries left."
            count=$((count-1))
        fi
    done
    if [ $count -eq 0 ]; then
        echo "You have entered the wrong key three times."
        echo "Now, The program will exit"
        exit
    fi
}

if [ $# -eq 2 ]
then
    start $1 $2
else
    echo "You have entered the wrong number of parameters. Enter username and ID togather."
fi
